# rule: module
assert False

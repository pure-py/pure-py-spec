# rule: unop
print(-"a")

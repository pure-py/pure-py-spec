# rule: pat-shapes
v: int = 1
match v:
    case x:
        print(x)
    case 1:
        print("lit")

x: int = 42

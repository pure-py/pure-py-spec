# rule: qual-guard
ks: list[str] = ["a", "bb", "ccc"]
print({k: len(k) for k in ks if len(k) > 1})

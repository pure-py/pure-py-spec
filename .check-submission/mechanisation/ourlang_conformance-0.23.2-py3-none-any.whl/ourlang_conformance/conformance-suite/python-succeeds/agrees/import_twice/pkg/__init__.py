w: int = 0

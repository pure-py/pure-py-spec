# rule: binop
t: tuple[int, int, int] = (1, 2, 3)
print(2 in t)
print(5 not in t)

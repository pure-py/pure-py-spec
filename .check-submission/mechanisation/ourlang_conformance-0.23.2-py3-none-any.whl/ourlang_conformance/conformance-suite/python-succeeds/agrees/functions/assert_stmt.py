# rule: assert
x: int = 5
assert x == 5
print(x)

# rule: return
def f() -> int:
    return 1
print(f())

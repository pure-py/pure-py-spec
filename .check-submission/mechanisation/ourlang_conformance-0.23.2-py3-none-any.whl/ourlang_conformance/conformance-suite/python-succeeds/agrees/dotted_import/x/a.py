z: int = 42

# rule: eval-subscript
xs: list[int] = [10, 20, 30]
print(xs[-1])
print(xs[-3])
